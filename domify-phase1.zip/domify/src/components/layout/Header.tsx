"use client";

import Link from "next/link";
import { useState } from "react";
import { Menu, X, Search, Building2, Heart, User } from "lucide-react";

const NAV = [
  { label: "Acheter", href: "/proprietes?type=vente" },
  { label: "Louer", href: "/proprietes?type=location" },
  { label: "Projets", href: "/projets" },
  { label: "Agences", href: "/agences" },
  { label: "Blog", href: "/blog" },
  { label: "Contact", href: "/contact" },
];

export function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full border-b border-black/5 bg-white/95 backdrop-blur">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link href="/" className="flex items-center gap-2">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-domify-primary text-white">
            <Building2 size={18} />
          </span>
          <span className="font-display text-xl font-semibold tracking-tight text-domify-dark">
            DOMIFY
          </span>
        </Link>

        <nav className="hidden items-center gap-8 lg:flex">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="text-sm font-medium text-domify-dark/80 transition-luxury hover:text-domify-primary"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-4 lg:flex">
          <button aria-label="Rechercher" className="text-domify-dark/70 hover:text-domify-primary transition-luxury">
            <Search size={19} />
          </button>
          <Link href="/favoris" aria-label="Favoris" className="text-domify-dark/70 hover:text-domify-primary transition-luxury">
            <Heart size={19} />
          </Link>
          <Link href="/connexion" aria-label="Mon compte" className="text-domify-dark/70 hover:text-domify-primary transition-luxury">
            <User size={19} />
          </Link>
          <Link
            href="/estimation"
            className="rounded-full bg-domify-gold px-5 py-2.5 text-sm font-semibold text-white shadow-luxury transition-luxury hover:bg-domify-soft-gold hover:text-domify-dark"
          >
            Estimer mon bien
          </Link>
        </div>

        <button className="lg:hidden" onClick={() => setOpen(!open)} aria-label="Menu">
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {open && (
        <div className="border-t border-black/5 bg-white px-4 py-4 lg:hidden">
          <nav className="flex flex-col gap-4">
            {NAV.map((item) => (
              <Link key={item.href} href={item.href} className="text-sm font-medium text-domify-dark/80" onClick={() => setOpen(false)}>
                {item.label}
              </Link>
            ))}
            <Link
              href="/estimation"
              className="mt-2 rounded-full bg-domify-gold px-5 py-2.5 text-center text-sm font-semibold text-white"
              onClick={() => setOpen(false)}
            >
              Estimer mon bien
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}
