// TEMPORARY sample data for the UI preview phase.
// In the full build this is replaced by Prisma queries against PostgreSQL
// (see prisma/schema.prisma for the real Property model).

export type Property = {
  id: string;
  title: string;
  city: string;
  price: number;
  type: "vente" | "location";
  bedrooms: number;
  bathrooms: number;
  area: number;
  image: string;
  badge?: string;
};

export const featuredProperties: Property[] = [
  {
    id: "1",
    title: "Villa contemporaine",
    city: "Bouskoura",
    price: 5600000,
    type: "vente",
    bedrooms: 4,
    bathrooms: 4,
    area: 450,
    image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=1200&auto=format&fit=crop",
    badge: "Villa d'exception",
  },
  {
    id: "2",
    title: "Appartement moderne",
    city: "Casablanca",
    price: 2350000,
    type: "vente",
    bedrooms: 3,
    bathrooms: 2,
    area: 120,
    image: "https://images.unsplash.com/photo-1613977257363-707ba9348227?q=80&w=1200&auto=format&fit=crop",
    badge: "Appartement neuf",
  },
  {
    id: "3",
    title: "Villa avec piscine",
    city: "Rabat",
    price: 7800000,
    type: "vente",
    bedrooms: 6,
    bathrooms: 5,
    area: 600,
    image: "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?q=80&w=1200&auto=format&fit=crop",
    badge: "Villa de luxe",
  },
  {
    id: "4",
    title: "Duplex moderne",
    city: "Casablanca",
    price: 3200000,
    type: "vente",
    bedrooms: 3,
    bathrooms: 3,
    area: 160,
    image: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?q=80&w=1200&auto=format&fit=crop",
    badge: "Duplex haut standing",
  },
];
